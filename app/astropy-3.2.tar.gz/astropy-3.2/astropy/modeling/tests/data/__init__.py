# Licensed under a 3-clause BSD style license - see LICENSE.rst

import os

dpath = os.path.split(os.path.abspath(__file__))[0]
